synthetic fixture: readme
